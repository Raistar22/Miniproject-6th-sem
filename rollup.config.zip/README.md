# GUN Chat Dapp Demo

A decentralized chat app built with [GUN](https://gun.eco/). 

- Try the [Live Demo](https://gun-chat-dapp.web.app/)
- Watch the [Chat Dapp Video](https://youtu.be/J5x3OMXjgMc)

```
git clone <this-repo>
npm install
npm run dev
```